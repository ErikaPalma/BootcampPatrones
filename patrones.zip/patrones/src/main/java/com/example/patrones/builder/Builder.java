package com.example.patrones.builder;

public class Builder {
	
	void setSeats(int seats) {
	}
	void setWheels(int wheels) {
	}

}
