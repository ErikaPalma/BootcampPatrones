package com.example.patrones.builder;

public class CarType {

}
