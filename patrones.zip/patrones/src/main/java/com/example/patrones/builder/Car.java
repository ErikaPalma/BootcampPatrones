package com.example.patrones.builder;

public class Car {
	
	private int seats;
	private int wheels;
	
	public Car( int seats, int wheels) {
		
		this.seats = seats;
		this.wheels = wheels;
	}
	
	public void setWheels(int wheels) {
		this.wheels = wheels;
	}
	
	public void setSeats(int seats) {
		this.seats = seats;
	}

	public int getWheels() {
		return wheels;
	}
	
	public int getSeats() {
		return seats;
	}
	
	

}
