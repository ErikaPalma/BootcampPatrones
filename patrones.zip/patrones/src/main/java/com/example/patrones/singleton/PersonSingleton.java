package com.example.patrones.singleton;

public class PersonSingleton {

<<<<<<< HEAD
	   private static PersonSingleton instance;
=======
	   private static  PersonSingleton instance;
>>>>>>> 99cca903a91f91438f788cac7895e925a9c6e889
	   
	   private String name;
	   private int age;

<<<<<<< HEAD
	   private PersonSingleton() {
		  
	   }
=======
	   private PersonSingleton() {}
>>>>>>> 99cca903a91f91438f788cac7895e925a9c6e889

	   public static PersonSingleton getInstance() {
	       if (instance == null) {
	           instance = new PersonSingleton();
	       }
	       return instance;
	   }
	   
<<<<<<< HEAD
	   
=======
>>>>>>> 99cca903a91f91438f788cac7895e925a9c6e889
	   public void singletonOperation() {
		   System.out.println("Persona");
	   }
	}